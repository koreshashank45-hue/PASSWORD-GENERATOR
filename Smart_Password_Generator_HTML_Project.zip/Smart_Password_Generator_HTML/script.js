const lengthSlider = document.getElementById("length");
const lengthValue = document.getElementById("lengthValue");
const generatedPassword = document.getElementById("generatedPassword");
const generatedStrength = document.getElementById("generatedStrength");
const checkedStrength = document.getElementById("checkedStrength");

lengthSlider.addEventListener("input", () => {
  lengthValue.textContent = lengthSlider.value;
});

function secureIndex(max) {
  const values = new Uint32Array(1);
  const limit = Math.floor(0x100000000 / max) * max;
  let value;
  do {
    crypto.getRandomValues(values);
    value = values[0];
  } while (value >= limit);
  return value % max;
}

function shuffle(items) {
  for (let i = items.length - 1; i > 0; i--) {
    const j = secureIndex(i + 1);
    [items[i], items[j]] = [items[j], items[i]];
  }
  return items;
}

function strengthOf(password) {
  let score = 0;
  const hasLower = /[a-z]/.test(password);
  const hasUpper = /[A-Z]/.test(password);
  const hasDigit = /[0-9]/.test(password);
  const hasSymbol = /[^a-zA-Z0-9]/.test(password);

  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (hasLower) score++;
  if (hasUpper) score++;
  if (hasDigit) score++;
  if (hasSymbol) score++;

  return score >= 5 ? "Strong" : score >= 3 ? "Medium" : "Weak";
}

function showStrength(element, password) {
  const strength = strengthOf(password);
  element.textContent = `Password Strength: ${strength}`;
  element.className = "strength " + strength.toLowerCase();
}

document.getElementById("generateBtn").addEventListener("click", () => {
  const groups = [];
  if (document.getElementById("lower").checked) groups.push("abcdefghijklmnopqrstuvwxyz");
  if (document.getElementById("upper").checked) groups.push("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
  if (document.getElementById("numbers").checked) groups.push("0123456789");
  if (document.getElementById("symbols").checked) groups.push("!@#$%^&*");

  const length = Number(lengthSlider.value);
  if (groups.length === 0) {
    generatedPassword.value = "";
    generatedStrength.textContent = "Select at least one character type.";
    generatedStrength.className = "strength weak";
    return;
  }
  if (length < groups.length) {
    generatedPassword.value = "";
    generatedStrength.textContent = `Choose a length of at least ${groups.length} for the selected character types.`;
    generatedStrength.className = "strength weak";
    return;
  }

  const all = groups.join("");
  const chars = groups.map(group => group[secureIndex(group.length)]);
  while (chars.length < length) chars.push(all[secureIndex(all.length)]);
  generatedPassword.value = shuffle(chars).join("");
  showStrength(generatedStrength, generatedPassword.value);
});

document.getElementById("copyBtn").addEventListener("click", async () => {
  if (!generatedPassword.value) {
    generatedStrength.textContent = "Generate a password first.";
    generatedStrength.className = "strength weak";
    return;
  }
  try {
    await navigator.clipboard.writeText(generatedPassword.value);
    generatedStrength.textContent = "Password copied to clipboard.";
    generatedStrength.className = "strength strong";
  } catch {
    generatedPassword.select();
    generatedStrength.textContent = "Select and copy the password manually.";
    generatedStrength.className = "strength medium";
  }
});

document.getElementById("checkBtn").addEventListener("click", () => {
  const password = document.getElementById("passwordInput").value;
  if (!password) {
    checkedStrength.textContent = "Please enter a password.";
    checkedStrength.className = "strength weak";
    return;
  }
  showStrength(checkedStrength, password);
});
