# Smart Password Generator & Strength Checker (HTML)

## Files
- `index.html` — application structure
- `style.css` — page styling and responsive layout
- `script.js` — password generation and strength-checking logic

## How to run
1. Extract the ZIP file.
2. Open the folder in Visual Studio Code.
3. Open `index.html` in a browser (or use the VS Code Live Server extension).
4. Choose password length and character types, then click **Generate Password**.
5. To evaluate an existing password, enter it in the checker and click **Check Strength**.

## Notes
- Password generation uses the browser Web Crypto API (`crypto.getRandomValues`).
- Passwords are generated locally in the browser; this project does not send them to a server.
- Strength classification is a simple educational estimate, not a full security audit.
