# Smart Password Generator & Strength Checker

A basic, menu-driven Java console mini project. It can generate random passwords and provide a simple strength estimate for a password entered by the user.

## Features
- Generate passwords with lowercase letters, uppercase letters, digits, and symbols.
- Select a password length from 4 to 50 characters.
- Ensure generated passwords contain at least one character from each category.
- Shuffle generated characters using `SecureRandom`.
- Check a user-entered password and classify it as **Weak**, **Medium**, or **Strong**.
- Validate menu input and password length.

## Requirements
- JDK 8 or later
- Visual Studio Code (optional) with the Java Extension Pack, or any Java IDE/terminal

## Run from a terminal
Open a terminal in the project folder and run:

```bash
javac src/PasswordGenerator.java
java -cp src PasswordGenerator
```

Alternatively, open the `src` folder in VS Code and run `PasswordGenerator.java` using the Java extension.

## Menu
1. Generate Password
2. Check Password Strength
3. Exit

## Project structure

```text
Smart_Password_Generator_Project/
├── src/
│   └── PasswordGenerator.java
├── assets/
│   ├── main_menu.png
│   ├── password_generation.png
│   ├── password_strength_weak.png
│   ├── password_strength_strong.png
│   └── logo.png
├── report/
│   └── Smart_Password_Generator_Cleaned_Report.pdf
└── README.md
```

## Important note about strength checking
The Weak/Medium/Strong result is a basic educational score based on password length and character categories. It is not a complete security audit and does not check for common passwords, dictionary words, predictable patterns, or breached passwords. Do not use this project as a production password manager.

## Source code note
The `choice` variable is initialised to `0` in `main()` so that the `do-while` loop condition is valid even when the user enters non-numeric input before making a valid menu selection.
